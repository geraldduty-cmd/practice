import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/')({
  component: GeraldDutyPortfolio,
})

function GeraldDutyPortfolio() {
  return (
    <div className="bg-white text-gray-800 font-serif min-h-screen">
      {/* Header / Navigation */}
      <header className="border-b border-gray-200 sticky top-0 bg-white z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="#hero" className="text-sm font-semibold tracking-widest uppercase text-gray-900">
            Gerald Duty
          </a>
          <nav className="hidden md:flex items-center gap-8">
            {[
              { label: 'Thesis', href: '#thesis' },
              { label: 'Practice', href: '#practice' },
              { label: 'Matters', href: '#matters' },
              { label: 'Insights', href: '#insights' },
              { label: 'About', href: '#about' },
              { label: 'Contact', href: '#contact' },
            ].map(({ label, href }) => (
              <a
                key={label}
                href={href}
                className="text-sm text-gray-500 hover:text-gray-900 tracking-wide transition-colors"
              >
                {label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section id="hero" className="border-b border-gray-200 py-24 md:py-36">
        <div className="max-w-6xl mx-auto px-6">
          <h1 className="text-4xl md:text-6xl font-light leading-tight text-gray-900 max-w-3xl mb-8">
            Counsel in complex, cross-border, and non-standard situations.
          </h1>
          <p className="text-lg md:text-xl text-gray-500 max-w-2xl leading-relaxed">
            Engaged by founders, investors, and institutions navigating sophisticated transactions, regulatory complexity, and emerging markets — particularly across Latin America and the Caribbean.
          </p>
        </div>
      </section>

      {/* Practice Thesis */}
      <section id="thesis" className="border-b border-gray-200 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-[1fr_2fr] gap-16">
            <div>
              <h2 className="text-xs font-semibold tracking-widest uppercase text-gray-400 mb-2">
                Practice Thesis
              </h2>
            </div>
            <div className="space-y-6 text-gray-600 leading-relaxed">
              <p>
                The practice is built around a single conviction: that the most consequential legal work happens at the edges — where jurisdictions meet, where markets are emerging or in transition, and where standard frameworks no longer provide clear guidance. Gerald Duty operates in precisely these spaces, advising clients who require counsel comfortable with ambiguity and capable of structuring solutions that are both legally sound and commercially viable.
              </p>
              <p>
                The practice has a particular focus on Latin America and the Caribbean, regions that present unique opportunities for cross-border investment, regulatory arbitrage, and institutional development. Gerald brings deep familiarity with the regulatory environments, capital markets, and legal systems of these markets, as well as the relationships necessary to navigate them effectively.
              </p>
              <p>
                Clients are typically founders building regional businesses, private equity and venture investors deploying capital across borders, financial institutions entering new markets, and established multinationals managing complex regulatory exposure. What they share is a need for counsel who can think across jurisdictions, across disciplines, and across the transaction lifecycle.
              </p>
              <p>
                The practice does not seek to be everything to everyone. It is deliberately narrow in its focus and deliberately deep in its expertise — structured to provide the kind of senior, engaged, judgment-driven counsel that complex situations demand.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Practice Areas */}
      <section id="practice" className="border-b border-gray-200 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-xs font-semibold tracking-widest uppercase text-gray-400 mb-14">
            Practice
          </h2>
          <div className="grid md:grid-cols-2 gap-0">
            {[
              {
                title: 'Cross-Border Transactions',
                description:
                  'Structuring and executing M&A, joint ventures, and investment transactions involving multiple jurisdictions — with particular depth in Latin America, the Caribbean, and transactions between these regions and the United States and Europe. Advising on deal structure, regulatory approvals, and cross-border governance from term sheet through closing.',
              },
              {
                title: 'Regulatory Strategy',
                description:
                  'Guiding clients through the regulatory complexities of operating in emerging and frontier markets, including licensing, compliance, government relations, and navigating regulatory change. Particular experience with financial services regulation, foreign investment regimes, and the intersection of U.S. law and local regulatory requirements.',
              },
              {
                title: 'Special Situations',
                description:
                  'Advising on transactions and legal matters that fall outside conventional categories — including distressed situations, sanctioned or post-sanction markets, complex restructurings, and novel legal questions arising from new market entrants. Combining legal creativity with practical judgment to find workable paths forward.',
              },
              {
                title: 'Private Capital & Partnerships',
                description:
                  'Counseling private equity funds, family offices, and institutional investors on fund formation, co-investment structures, and portfolio company matters in cross-border contexts. Advising on partnership agreements, governance frameworks, and the legal architecture of long-term capital relationships.',
              },
            ].map((area, i) => (
              <div
                key={area.title}
                className={`p-10 border-gray-200 ${
                  i % 2 === 0 ? 'border-r' : ''
                } ${i < 2 ? 'border-b' : ''}`}
              >
                <h3 className="text-lg font-semibold text-gray-900 mb-4">{area.title}</h3>
                <p className="text-gray-500 leading-relaxed text-sm">{area.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Representative Matters */}
      <section id="matters" className="border-b border-gray-200 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-[1fr_2fr] gap-16">
            <div>
              <h2 className="text-xs font-semibold tracking-widest uppercase text-gray-400 mb-2">
                Representative Matters
              </h2>
              <p className="text-xs text-gray-400 mt-4 leading-relaxed">
                Select matters. Client identities withheld where confidentiality applies.
              </p>
            </div>
            <ul className="space-y-6">
              {[
                'Advised a consortium of regional investors on the acquisition of a Caribbean commercial bank, including regulatory approval processes before multiple supervisory authorities, capital structure negotiations, and post-acquisition governance framework.',
                'Structured a cross-border joint venture between a U.S. private equity fund and a Latin American operating company for the development and management of infrastructure assets, including negotiation of governance rights, exit mechanisms, and currency risk allocation.',
                'Counseled a fintech company on its regulatory strategy for expansion across five Caribbean jurisdictions, including licensing applications, compliance program design, and engagement with central bank and financial intelligence unit regulators.',
                'Advised a European institutional investor on the legal and regulatory dimensions of re-entry into a previously sanctioned Latin American market following partial sanctions relief, including OFAC compliance analysis and investment structure design.',
                'Represented a regional family office in a complex multi-party recapitalization of a distressed media and telecommunications company, involving debt restructuring, equity dilution negotiations, and resolution of competing creditor claims across multiple legal systems.',
              ].map((matter, i) => (
                <li key={i} className="flex gap-4">
                  <span className="text-gray-300 font-light text-lg leading-none mt-0.5">—</span>
                  <p className="text-gray-600 leading-relaxed text-sm">{matter}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Insights */}
      <section id="insights" className="border-b border-gray-200 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-xs font-semibold tracking-widest uppercase text-gray-400 mb-14">
            Insights
          </h2>
          <article className="grid md:grid-cols-[1fr_2fr] gap-16">
            <div>
              <p className="text-xs text-gray-400 tracking-wide uppercase mb-2">Analysis</p>
              <p className="text-xs text-gray-400">March 2024</p>
            </div>
            <div>
              <h3 className="text-2xl font-light text-gray-900 mb-6 leading-snug">
                Sanctions Reversibility in Venezuela: Legal Considerations for Investors Watching the Apertura
              </h3>
              <div className="space-y-4 text-gray-600 leading-relaxed text-sm">
                <p>
                  The partial and episodic easing of U.S. sanctions on Venezuela over the past several years has created a pattern familiar to practitioners in sanctions law: a cycle of licenses issued, suspended, reinstated, and re-suspended, generating significant compliance uncertainty for investors seeking to position for eventual normalization.
                </p>
                <p>
                  For foreign investors, the operative question is not merely whether sanctions relief will come, but how to structure investments so that they can be activated quickly when relief arrives — and wound down cleanly if it is reversed. This requires thinking about sanctions not as a static condition but as a legal variable to be engineered around.
                </p>
                <p>
                  Several structural tools have emerged from practice in analogous markets — Cuba, Iran, Myanmar — that offer useful frameworks. These include holding structures that place sanctioned assets in segregated vehicles, contractual provisions that create clear activation triggers tied to OFAC license status, and governance arrangements that allow non-U.S. partners to manage assets during periods of U.S. person exclusion without creating impermissible facilitation exposure.
                </p>
                <p>
                  The Venezuelan situation adds layers of complexity not present in all sanctioned markets: the contested sovereignty question (which counterparty has authority to grant concessions or consent to transfers), the dollarization of large segments of the economy (which affects currency risk analysis), and the presence of third-country investors — particularly from China, Russia, and Turkey — whose interests and legal positions may conflict with those of U.S.-adjacent investors positioning for the apertura.
                </p>
                <p>
                  Investors with genuine interest in Venezuela should be building their legal architecture now, not when licenses are granted. The window between relief announcement and competitive deployment of capital is typically narrow, and structural deficiencies that seemed theoretical become acute precisely at the moment of greatest urgency.
                </p>
              </div>
            </div>
          </article>
        </div>
      </section>

      {/* About */}
      <section id="about" className="border-b border-gray-200 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-[1fr_2fr] gap-16">
            <div>
              <h2 className="text-xs font-semibold tracking-widest uppercase text-gray-400 mb-2">
                About
              </h2>
            </div>
            <div className="space-y-5 text-gray-600 leading-relaxed">
              <p>
                Gerald Duty is an international corporate attorney whose practice focuses on cross-border transactions, regulatory strategy, and complex legal matters in Latin America and the Caribbean. He advises a range of clients — from early-stage founders navigating multi-jurisdictional legal questions for the first time, to institutional investors with sophisticated needs in emerging and frontier markets.
              </p>
              <p>
                Gerald brings experience across the transaction lifecycle, including deal structuring, regulatory approval processes, cross-border joint ventures, private capital formation, and special situations work involving distressed assets or markets undergoing legal and political transition. His work is characterized by a willingness to engage with novel legal questions and a focus on practical, commercially grounded advice.
              </p>
              <p>
                He has advised clients on matters touching jurisdictions across the Caribbean basin, Central and South America, and in cross-border matters involving the United States, Europe, and Latin American counterparties. He maintains familiarity with the regulatory frameworks, legal systems, and business environments of key markets in the region, and brings relationships across the private sector, regulatory agencies, and the legal community in those markets.
              </p>
              <p>
                Gerald is based in the United States and works with clients across time zones and jurisdictions. His practice operates with the flexibility and senior engagement appropriate to the complexity of the matters he handles.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-[1fr_2fr] gap-16">
            <div>
              <h2 className="text-xs font-semibold tracking-widest uppercase text-gray-400 mb-2">
                Contact
              </h2>
            </div>
            <div>
              <div className="mb-10">
                {/* Logo placeholder — replace src with actual RPA Logo if available */}
                <div className="mb-8 text-sm font-semibold tracking-widest uppercase text-gray-900 border border-gray-200 inline-block px-5 py-3">
                  RPA
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-500">Richards &amp; Partners Associates</p>
                </div>
              </div>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-gray-400 tracking-wide uppercase mb-1">Firm</p>
                  <a
                    href="mailto:gduty@richards-law.com"
                    className="text-gray-700 hover:text-gray-900 transition-colors text-sm"
                  >
                    gduty@richards-law.com
                  </a>
                </div>
                <div>
                  <p className="text-xs text-gray-400 tracking-wide uppercase mb-1">Direct</p>
                  <a
                    href="mailto:gerald@geraldduty.com"
                    className="text-gray-700 hover:text-gray-900 transition-colors text-sm"
                  >
                    gerald@geraldduty.com
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-8">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <p className="text-xs text-gray-400">
            &copy; {new Date().getFullYear()} Gerald Duty. All rights reserved.
          </p>
          <p className="text-xs text-gray-400">
            Attorney Advertising. Prior results do not guarantee a similar outcome.
          </p>
        </div>
      </footer>
    </div>
  )
}
